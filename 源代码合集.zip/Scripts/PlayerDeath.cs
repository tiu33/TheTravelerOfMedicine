using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;   // ǣ��������������

public class PlayerDeath : MonoBehaviour
{
    private Animator anim;
    private Rigidbody2D rb;
    private PlayerHealth playerHealth;
    public GameObject playerPS;
    public int trapDamage = 1;  // �����˺�

    public AudioSource audios;
    public string LevelName;
    [SerializeField] AudioClip dealth;
    private void Start()
    {
        playerHealth = GetComponent<PlayerHealth>();
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Trap")
        {
            playerHealth.DamagePlayer(trapDamage);
        }
        if (collision.tag == "dieLine")
        {
            Death();
        }
    }

    //private void OnTriggerEnter2D(Collider2D collision)
    //{
    //    if (collision.tag == "dieLine")
    //    {
    //        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    //    }
    //}

    public void Death()
    {
        audios.clip = dealth;
        audios.Play();
        rb.bodyType = RigidbodyType2D.Static;
        anim.SetTrigger("death");
        Invoke("Restart", 1f);
        Destroy(playerPS, 1.05f);    // �����ű��ǰ��ڽ�ɫ���ϵ�   
    }
    private void Restart()
    {
        SceneManager.LoadScene(LevelName);
    }
}
