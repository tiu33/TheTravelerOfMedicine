using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Finish : MonoBehaviour
{
    private AudioSource finshing;
    private Fruits fruits;
    private bool isEnd;
    private bool button;
    public GameObject Button;

    void Start()
    {
        finshing = GetComponent<AudioSource>();
        fruits = GameObject.FindGameObjectWithTag("Player").GetComponent<Fruits>();
    }
    void Update()
    {
        button = Input.GetButtonDown("EnterDoor");
        if (button && isEnd)
        {
            finshing.Play();
            fruits.bananaGo();
        }
        //end = Input.GetButtonDown("EnterDoor");
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player") && collision.GetType().ToString() == "UnityEngine.CapsuleCollider2D")
        {
            Button.SetActive(true);
            //Debug.Log("Player�����ŵķ�Χ");
            isEnd = true;
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player") && collision.GetType().ToString() == "UnityEngine.CapsuleCollider2D")
        {
            Button.SetActive(false);
            //Debug.Log("Player�뿪�ŵķ�Χ");
            isEnd = false;
        }
    }
}
