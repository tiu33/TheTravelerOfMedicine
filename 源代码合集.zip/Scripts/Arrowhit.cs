using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arrowhit : MonoBehaviour
{
    public GameObject arrowPrefeb;
    public bool isShoot;
    public float coolTime;
    public float currentTime = 0f;
    void Start()
    {
        AmmoBar.currentTime = currentTime;
        AmmoBar.coolTime = coolTime;
    }

    void Update()
    {
        isShoot = Input.GetButtonDown("ArrowHit");
        if (isShoot && currentTime >= coolTime)
        {
            Shoot();
            currentTime = 0f;
            AmmoBar.currentTime = currentTime;  // ����UI���
        }
        else if (currentTime <= coolTime)
        {
            currentTime += Time.deltaTime;
            AmmoBar.currentTime = currentTime;
        }
    }
    void Shoot()
    {
        Instantiate(arrowPrefeb,transform.position,transform.rotation);
    }
}
