using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SawMoving : MonoBehaviour
{
    [SerializeField] private GameObject[] points;   // ������忴���������ű������� 
    [SerializeField] private float speed = 2f;  // ƽ̨�ƶ����ٶ�

    private int pointNum = 1;   // ���ȡֵ
    private float waitTime = 0.5f;
    void Update()
    {
        transform.position = Vector2.MoveTowards(transform.position, points[pointNum].transform.position, speed * Time.deltaTime);  // woc������������л���
        if (Vector2.Distance(transform.position, points[pointNum].transform.position) < 0.1f)
        {
            if (waitTime < 0)
            {
                if (pointNum == 0)
                {
                    pointNum = 1;
                }
                else
                {
                    pointNum = 0;
                }
                waitTime = 0.5f;
            }
            else
                waitTime -= Time.deltaTime;
        }
    }
}
