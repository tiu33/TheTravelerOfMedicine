using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Platform : MonoBehaviour
{
    //PlatformEffector2D pe2d;

    void Start()
    {
        //pe2d= GetComponent<PlatformEffector2D>();   // ��ʼ��
    }

    
    void Update()
    {
        //if (Input.GetKey(KeyCode.Alpha3))
        //{
        //    pe2d.rotationalOffset = 180f;
        //}
        //if (Input.GetKey(KeyCode.Alpha2))
        //{
        //    pe2d.rotationalOffset = 0f;
        //}
    }
}
