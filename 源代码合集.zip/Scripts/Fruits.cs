using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Fruits : MonoBehaviour
{
    public int bananas = 0;
    [SerializeField] private Text bananaText;
    public AudioSource audios;
    private PlayerHealth playerHealth;  // ��������
    [SerializeField] AudioClip collect;
    private void Start()
    {
        playerHealth = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerHealth>();
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Fruits"))
        {
            audios.clip = collect;
            audios.Play();
            Destroy(collision.gameObject);
            bananas++;
            bananaText.text = bananas.ToString();
        }
        if (collision.gameObject.CompareTag("Shouji"))
        {
            Debug.Log("ִ���ˣ�");
            audios.clip = collect;
            audios.Play();
        }

    }
    public void bananaSet(int number)
    {
        bananas = number;
        bananaText.text = bananas.ToString();   // ����¸������ǣ�1.һ��Ҫע����UI��ʾ��2.����Save��Load�Ļ���Ҫ�ø�����������
    }
    public void bananaHeal()
    {
        if (bananas > 0 && playerHealth.health < HealthBar.healthMax)
        {
            bananas--;
            bananaText.text = bananas.ToString();
            playerHealth.healPlayer(10);
        }
    }
    public void bananaGo()
    {
        if (bananas >= 30)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
    }
}

