using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartGame : MonoBehaviour
{
    public void StartMenu(string _LevelName)
    {
        SceneManager.LoadScene(_LevelName);
    }

    public void ExitMenu()
    {
        Application.Quit();
    }
}
