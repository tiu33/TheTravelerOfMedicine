using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogBase : MonoBehaviour
{
    public GameObject talkUI;
    private bool isPress;
    public GameObject Button;

    void Update()
    {
        isPress = Input.GetButtonDown("EnterDoor");
        if (Button.activeSelf && isPress)
        {
            talkUI.SetActive(true);
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        Button.SetActive(true);
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        Button.SetActive(false);
    }
}
