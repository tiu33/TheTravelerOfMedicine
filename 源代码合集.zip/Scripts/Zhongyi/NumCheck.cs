using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NumCheck : MonoBehaviour
{
    [Header("��ɼ�¼�����")]
    [SerializeField] public int task = 0;
    [Header("�ռ�ӣ�Ҹ���")]
    [SerializeField] public int cherryNum = 0;
    [Header("��һ����ȷҩ�ĸ���")]
    [SerializeField] public int yaoNum = 0;
    [Header("�ڶ�����ȷҩ�ĸ���")]
    [SerializeField] public int yaoSecondNum = 0;
    [Header("�ɽ����ؿ�����")]
    [SerializeField] public int guanNum = 0;
    [Header("�ռ�ҩ������")]
    public AudioSource yaoMusic;
    [SerializeField] AudioClip myYaoMusic;
    public int controlmusic = 0;
    [Header("�����Ŀ��")]
    public int rightQuestions = 0;

    private void Update()
    {
        if(controlmusic >= 1)
        {
            yaoMusic.clip = myYaoMusic;
            yaoMusic.Play();
            controlmusic = 0;
        }

        if (cherryNum >= 15)
        {
            task += 1;
            SceneManager.LoadScene("FirstLevel");
            cherryNum = 0;
        }
        if (yaoSecondNum == 4)
        {
            StartCoroutine(backToMenu2());   // ��ʱ��ת��ƽ������
            yaoNum = 0;
        }
        if (yaoNum == 4)
        {
            StartCoroutine(backToMenu());   // ��ʱ��ת��ƽ������
            yaoNum = 0;
        }

        if (rightQuestions == 15)
        {
            StartCoroutine(backToOpen());
            rightQuestions = 0;
        }
    }

    IEnumerator backToMenu()
    {
        yield return new WaitForSeconds(1.2f);
        task = 0;
        SceneManager.LoadScene("TheMenu");
        guanNum += 1;
    }
    IEnumerator backToMenu2()
    {
        yield return new WaitForSeconds(1.2f);
        task = 0;
        SceneManager.LoadScene("TheMenu");
        guanNum = 2;
    }
    IEnumerator backToOpen()
    {
        yield return new WaitForSeconds(1.2f);
        SceneManager.LoadScene("StartScenes");
    }

}
