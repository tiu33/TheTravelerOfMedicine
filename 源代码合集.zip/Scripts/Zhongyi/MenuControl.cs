using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuControl : MonoBehaviour
{
    public NumCheck num;
    public GameObject SecondLevel;
    public GameObject ThirdLevel;
    void Start()
    {
        num = GameObject.FindGameObjectWithTag("NumCheck").GetComponent<NumCheck>();
    }


    void Update()
    {
        if (num.guanNum >= 1)
        {
            SecondLevel.SetActive(true);
        }
        if (num.guanNum >= 2)
        {
            ThirdLevel.SetActive(true);
        }
    }
}
