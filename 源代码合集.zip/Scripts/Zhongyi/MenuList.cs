using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MenuList : MonoBehaviour
{
    public GameObject menuList;
    public GameObject Bgm;
    [SerializeField] private bool menuKeys = true;
    GameObject myBgm;
    AudioSource myGloabalBgm;
    private GameObject player;  // ���¿�ʼʱ�ݻ����
    public Slider sd;
    void Start()
    {
        #region ȫ�ֲ�ͣ��BGM
        myBgm = GameObject.FindGameObjectWithTag("Bgm");
        //if (myBgm == null)
        //{
        //    myBgm = (GameObject)Instantiate(Bgm);
        //}
        myGloabalBgm = myBgm.GetComponent<AudioSource>();
        #endregion
    }

    void Update()
    {
        if (menuKeys)   // ���Ʋ���δ򿪲˵�
        {
            if (Input.GetKeyUp(KeyCode.Escape)) // ��ESC���򿪲˵�
            {
                menuList.SetActive(true);
                menuKeys = false;
                Time.timeScale = (0);
                myGloabalBgm.Pause();
            }
        }
        else if (Input.GetKeyUp(KeyCode.Escape))
        {
            menuList.SetActive(false);
            menuKeys = true;
            Time.timeScale = (1);
            myGloabalBgm.Play();
        }
    }
    #region �˵�����
    public void OpenMenu()  // �����˵�
    {
        if(menuKeys)
        {
            menuList.SetActive(true);
            menuKeys = false;
            Time.timeScale = (0);
            myGloabalBgm.Pause();
        }
    }
    public void Return()    // ������Ϸ
    {
        if(!menuKeys)
        {
            //Debug.Log("��ִ��");
            menuList.SetActive(false);
            menuKeys = true;
            Time.timeScale = (1);
            myGloabalBgm.Play();
        }
    }
    public void Restart()   // ���¿�ʼ
    {
        SceneManager.LoadScene(0);
        Time.timeScale = 1;
        player = GameObject.FindGameObjectWithTag("TheAllPlayer");
        Destroy(player);
        myGloabalBgm.Play();
    }
    public void Exit()  // �˳���Ϸ
    {
        Application.Quit();
    }
    public void ControlMusic()  // ��������
    {
        myGloabalBgm.volume = sd.value;
    }
    public void EnterMenu()
    {
        if (menuKeys)
        {
            menuList.SetActive(true);
            menuKeys = false;
            Time.timeScale = (0);
            myGloabalBgm.Pause();
        }   
    }
    public void ExitMenu()
    {
        menuList.SetActive(false);
        menuKeys = true;
        Time.timeScale = (1);
        myGloabalBgm.Play();
    }
    #endregion

}
