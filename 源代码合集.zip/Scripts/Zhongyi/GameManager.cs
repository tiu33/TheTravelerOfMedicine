using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    [Header("�ȶԿ��Ƶ��嵥")]
    public List<Card> cardComparison;

    [Header("���������嵥")]
    public List<CardPattern> cardsToBePutIn;

    [Header("�Ѿ��ɹ���Կ�������")]
    public int matchedCardsCount = 0;

    public Fruits playerNum;
    public Transform playerTransform;

    [Header("Ŀ�����ɵص�")]
    public Transform pointTransform;

    public Transform[] positions;

    public NumCheck num;

    void Start()
    {
        num = GameObject.FindGameObjectWithTag("NumCheck").GetComponent<NumCheck>();
        GenerateCardsToBePutIn();
        playerNum = GameObject.FindGameObjectWithTag("Player").GetComponent<Fruits>();
        playerTransform = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        playerTransform.position = pointTransform.position;
        //SetupCardsToBePutIn();
        //AddNewCard(CardPattern.����1);
    }

    void SetupCardsToBePutIn()  // EnumתList
    {
        Array array = Enum.GetValues(typeof(CardPattern));
        foreach (var card in array)
        {
            cardsToBePutIn.Add((CardPattern)card);
        }
        cardsToBePutIn.RemoveAt(0); // ɾ����ǰ�����
    }

    #region ����������
    void GenerateCardsToBePutIn()
    {
        int positionIndex = 0;
        for(int i = 0; i < 2; i++)
        {
            SetupCardsToBePutIn();
            int maxRandomNumber = cardsToBePutIn.Count; // �������

            for (int j = 0; j < maxRandomNumber; maxRandomNumber--)
            {
                int RandomNumber = UnityEngine.Random.Range(0, maxRandomNumber);    // ��������
                AddNewCard(cardsToBePutIn[RandomNumber], positionIndex);
                cardsToBePutIn.RemoveAt(RandomNumber);
                positionIndex++;
            }
        }
    }
    void AddNewCard(CardPattern cardPattern,int positionIndex)
    {
        GameObject card = Instantiate(Resources.Load<GameObject>("Prefabs/Card"));
        card.GetComponent<Card>().CardPattern = cardPattern;
        card.name = "��_" + cardPattern.ToString();
        card.transform.position = positions[positionIndex].position;

        GameObject graphic = Instantiate(Resources.Load<GameObject>("Prefabs/96"));
        graphic.GetComponent<SpriteRenderer>().sprite =
            Resources.Load<Sprite>("Graphic/" + cardPattern.ToString());
        graphic.transform.SetParent(card.transform);    // ����Ƶ������
        graphic.transform.localPosition = new Vector3(0, 0, 0.1f);  // �趨����
        graphic.transform.eulerAngles = new Vector3(0, 180, 0); // ˳y��ת180�ȣ����Ʋ������ҵߵ�
    }

    public void AddCardInCardComparison(Card card)
    {
        cardComparison.Add(card);
    }
    #endregion
    public bool ReadyToCompareCards
    {
        get
        {
            if(cardComparison.Count == 2)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    #region �������
    public void CompareCardInList()
    {
        if (ReadyToCompareCards)
        {
            //Debug.Log("���ԱȶԿ�����");
            if (cardComparison[0].CardPattern == cardComparison[1].CardPattern)
            {
                Debug.Log("����һ��");
                foreach (var card in cardComparison)
                {
                    card.cardState = CardState.��Գɹ�;
                }
                ClearCardComparison();
                matchedCardsCount += 2; // �ɹ���Կ���������2
                if(matchedCardsCount >= positions.Length)
                {
                    playerNum.bananas += 1;
                    num.task += 1;
                    SceneManager.LoadScene("FirstLevel");
                }
            }
            else
            {
                Debug.Log("���Ų�һ��");
                StartCoroutine(MissMatchCards());
                
            }
        }
    }

    void ClearCardComparison()
    {
        cardComparison.Clear();
    }

    void TurnBackCards()
    {
        foreach(var card in cardComparison)
        {
            card.gameObject.transform.eulerAngles = Vector3.zero;
            card.cardState = CardState.δ����;
        }
    }
    IEnumerator MissMatchCards()
    {
        yield return new WaitForSeconds(1.5f);
        TurnBackCards();
        ClearCardComparison();
    }
    #endregion
    
}
