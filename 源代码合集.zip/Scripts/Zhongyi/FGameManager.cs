using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FGameManager : MonoBehaviour
{
    public Fruits playerNum;
    public Transform playerTransform;
    public Transform pointTransform1;
    public Transform pointTransform2;
    public Transform pointTransform3;
    public NumCheck num;

    void Start()
    {
        playerNum = GameObject.FindGameObjectWithTag("Player").GetComponent<Fruits>();
        playerTransform = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        num = GameObject.FindGameObjectWithTag("NumCheck").GetComponent<NumCheck>();
       
        if (num.task == 0)
        {
            playerTransform.position = pointTransform1.position;
        }
        if (num.task == 1)
        {
            playerTransform.position = pointTransform2.position;

        }
        if (num.task >= 2)
        {
            playerTransform.position = pointTransform3.position;

        }

    }
}
