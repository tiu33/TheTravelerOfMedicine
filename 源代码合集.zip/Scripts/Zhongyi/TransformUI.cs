using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TransformUI : MonoBehaviour
{
    public GameObject now1;
    public GameObject change1;

    public GameObject now2_1;
    public GameObject change2_1;

    public GameObject now2_2;
    public GameObject change2_2;

    public GameObject now3_1;
    public GameObject change3_1;

    public GameObject now3_2;
    public GameObject change3_2;

    public GameObject now4_1;
    public GameObject change4_1;

    public GameObject now4_2;
    public GameObject change4_2;

    public GameObject now5_1;
    public GameObject change5_1;

    public GameObject now5_2;
    public GameObject change5_2;

    public GameObject now6_1;
    public GameObject change6_1;


    public void Tochange1()
    {
        change1.SetActive(true);
        now1.SetActive(false);
    }
    public void Tochange2_1()
    {
        change2_1.SetActive(true);
        now2_1.SetActive(false);
    }
    public void Tochange2_2()
    {
        change2_2.SetActive(true);
        now2_2.SetActive(false);
    }
    public void Tochange3_1()
    {
        change3_1.SetActive(true);
        now3_1.SetActive(false);
    }
    public void Tochange3_2()
    {
        change3_2.SetActive(true);
        now3_2.SetActive(false);
    }

    public void Tochange4_1()
    {
        change4_1.SetActive(true);
        now4_1.SetActive(false);
    }

    public void Tochange4_2()
    {
        change4_2.SetActive(true);
        now4_2.SetActive(false);
    }

    public void Tochange5_1()
    {
        change5_1.SetActive(true);
        now5_1.SetActive(false);
    }

    public void Tochange5_2()
    {
        change5_2.SetActive(true);
        now5_2.SetActive(false);
    }

    public void Tochange6_1()
    {
        change6_1.SetActive(true);
        now6_1.SetActive(false);
    }


}
