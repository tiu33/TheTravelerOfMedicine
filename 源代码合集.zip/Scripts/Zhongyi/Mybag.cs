using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mybag : MonoBehaviour
{
    public GameObject mybag;

    // Update is called once per frame
    void Update()
    {
        OpenMyBag();
    }

    void OpenMyBag()
    {
        if (Input.GetKeyDown(KeyCode.B))
        {
            mybag.SetActive(!mybag.activeSelf);
        }
    }
}
