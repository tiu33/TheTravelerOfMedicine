using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthControl : MonoBehaviour
{
    public PlayerHealth playhealth;
    public GameObject imagRed;
    public GameObject imagDark;
    [Header("����ֵ")]
    [SerializeField] private int point = 1;
    void Start()
    {
        playhealth = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerHealth>();
    }

    void Update()
    {
        if(playhealth.health >= point)
        {
            imagRed.SetActive(true);
            imagDark.SetActive(false); 
        }
        else
        {
            imagRed.SetActive(false);
            imagDark.SetActive(true); 
        }
    }
}
