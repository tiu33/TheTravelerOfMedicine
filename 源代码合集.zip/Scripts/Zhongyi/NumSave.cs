using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NumSave : MonoBehaviour
{
    private static NumSave example = null;

    private void Awake()
    {
        if (example == null)
        {
            example = this;
            DontDestroyOnLoad(gameObject);
        }
        else if (this != null)
        {
            Destroy(gameObject);
            return;
        }
    }
}
