using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wrongyao : MonoBehaviour
{

    public Vector2 mousePos;
    public Vector2 distance;
    public Rigidbody2D rb2D;
    public GameObject thisObject;
    public NumCheck num;
    public Transform pointTransform;


    void Start()
    {
        rb2D = GetComponent<Rigidbody2D>();
        num = GameObject.FindGameObjectWithTag("NumCheck").GetComponent<NumCheck>();
        rb2D.gravityScale = 3;
    }


    void Update()
    {
        mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Shui")
        {
            DestoryObject();
        }

    }
    private void OnMouseDown()
    {
        distance = new Vector2(transform.position.x, transform.position.y) - mousePos;
    }
    private void OnMouseDrag()
    {
        transform.position = mousePos + distance;
        rb2D.gravityScale = 0;
        rb2D.velocity = Vector2.zero;
    }
    private void OnMouseUpAsButton()
    {
        rb2D.gravityScale = 3;
    }
    public void DestoryObject()
    {
        //audios.clip = dealth;
        //audios.Play();
        thisObject.transform.position = pointTransform.position;

    }
}
