using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseManager : MonoBehaviour
{
    public Texture2D normal, dialogue;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        ChangeCursorTexture();
    }
    void ChangeCursorTexture()
    {
        Vector2 mouse = Input.mousePosition;
        var Ray = Camera.main.ScreenPointToRay(mouse);
        var hit = Physics2D.Raycast(new Vector2(Ray.origin.x, Ray.origin.y), Vector2.zero, Mathf.Infinity);
        if(hit.collider == null)
        {
            return;
        }
        switch(hit.collider.gameObject.tag)
        {
            default:
                Cursor.SetCursor(normal, new Vector2(16, 16), CursorMode.Auto);
                break;
            case "Yao":
                Cursor.SetCursor(dialogue, new Vector2(16, 16), CursorMode.Auto);
                StartCoroutine(backToNormal());
                break;
        }

    }
    IEnumerator backToNormal()
    {
        yield return new WaitForSeconds(2.0f);
        Cursor.SetCursor(normal, new Vector2(16, 16), CursorMode.Auto);
    }
}
