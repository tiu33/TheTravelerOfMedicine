using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseMove : MonoBehaviour
{
    public Vector2 mousePos;
    public Vector2 distance;
    public Rigidbody2D rb2D;
    public AudioSource audios;
    public GameObject thisObject;
    public NumCheck num;
    [SerializeField] AudioClip dealth;


    void Start()
    {
        rb2D = GetComponent<Rigidbody2D>();
        num = GameObject.FindGameObjectWithTag("NumCheck").GetComponent<NumCheck>();
        rb2D.gravityScale = 0;
    }

    // Update is called once per frame
    void Update()
    {
        mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "destoryObject")
        {
            DestoryObject();
        }

    }
    private void OnMouseDown()
    {
        distance = new Vector2(transform.position.x, transform.position.y) - mousePos;
    }
    private void OnMouseDrag()
    {
        transform.position = mousePos + distance;
        rb2D.gravityScale = 0;
        rb2D.velocity = Vector2.zero;
    }
    private void OnMouseUpAsButton()
    {
        rb2D.gravityScale = 3;
    }
    public void DestoryObject()
    {
        //audios.clip = dealth;
        //audios.Play();
        num.cherryNum += 1;
        Destroy(thisObject, 0.5f);    // �����ű��ǰ��ڽ�ɫ���ϵ�   
    }
}
