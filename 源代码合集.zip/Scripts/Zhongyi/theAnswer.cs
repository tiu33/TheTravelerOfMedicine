using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class theAnswer : MonoBehaviour
{
    //��ȡ�ĵ���ע���ļ�������utf-8
    string[][] ArrayX;//��Ŀ����
    string[] lineArray;//��ȡ����Ŀ����
    private int topicMax = 0;//�������
    private List<bool> isAnserList = new List<bool>();//����Ƿ������״̬

    //������Ŀ
    public GameObject tipsbtn;//��ʾ��ť
    public Text tipsText;//��ʾ��Ϣ
    public List<Toggle> toggleList;//����Toggle
    public Text indexText;//��ǰ�ڼ���
    public Text TM_Text;//��ǰ��Ŀ
    public List<Text> DA_TextList;//ѡ��
    private int topicIndex = 0;//�ڼ���

    //��ť���ܼ���ʾ��Ϣ
    public Button BtnBack;//��һ��
    public Button BtnNext;//��һ��
    public Button BtnTip;//��Ϣ����
    public Button BtnJump;//��ת��Ŀ
    public InputField jumpInput;//��ת��Ŀ
    public Text TextAccuracy;//��ȷ��
    private int anserint = 0;//�Ѿ��������
    private int isRightNum = 0;//��ȷ����

    //����ͼƬ
    public Image faceImage;
    public Sprite face00;
    public Sprite face01;
    public Sprite face02;
    public Sprite face03;
    public Sprite face04;
    public Sprite face05;
    public Sprite face06;
    public Sprite face07;
    public Sprite face08;
    public Sprite face09;
    public Sprite face10;
    public Sprite face11;
    public Sprite face12;
    public Sprite face13;
    public Sprite face14;

    //���������
    public NumCheck num;
    void Awake()
    {
        TextCsv();
        LoadAnswer();
    }

    void Start()
    {
        toggleList[0].onValueChanged.AddListener((isOn) => AnswerRightRrongJudgment(isOn, 0));
        toggleList[1].onValueChanged.AddListener((isOn) => AnswerRightRrongJudgment(isOn, 1));
        toggleList[2].onValueChanged.AddListener((isOn) => AnswerRightRrongJudgment(isOn, 2));
        toggleList[3].onValueChanged.AddListener((isOn) => AnswerRightRrongJudgment(isOn, 3));

        BtnTip.onClick.AddListener(() => Select_Answer(0));
        BtnBack.onClick.AddListener(() => Select_Answer(1));
        BtnNext.onClick.AddListener(() => Select_Answer(2));
        BtnJump.onClick.AddListener(() => Select_Answer(3));

        num = GameObject.FindGameObjectWithTag("NumCheck").GetComponent<NumCheck>();
    }

    #region ��ȡtxt����
    /*****************��ȡtxt����******************/
    void TextCsv()
    {
        //��ȡcsv�������ļ�  
        TextAsset binAsset = Resources.Load("test", typeof(TextAsset)) as TextAsset;
        //��ȡÿһ�е�����  
        lineArray = binAsset.text.Split('\r');
        //������ά����  
        ArrayX = new string[lineArray.Length][];
        //��csv�е����ݴ����ڶ�ά������  
        for (int i = 0; i < lineArray.Length; i++)
        {
            ArrayX[i] = lineArray[i].Split(':');
        }
        //������Ŀ״̬
        topicMax = lineArray.Length;
        for (int x = 0; x < topicMax + 1; x++)
        {
            isAnserList.Add(false);
        }
    }
    #endregion

    #region ������Ŀ
    /*****************������Ŀ******************/
    void LoadAnswer()
    {
        for (int i = 0; i < toggleList.Count; i++)
        {
            toggleList[i].isOn = false;
        }
        for (int i = 0; i < toggleList.Count; i++)
        {
            toggleList[i].interactable = true;
        }

        tipsbtn.SetActive(false);
        tipsText.text = "";

        indexText.text = "��" + (topicIndex + 1) + "�⣺";//�ڼ���
        TM_Text.text = ArrayX[topicIndex][1];//��Ŀ
        int idx = ArrayX[topicIndex].Length - 3;//�м���ѡ��
        for (int x = 0; x < idx; x++)
        {
            DA_TextList[x].text = ArrayX[topicIndex][x + 2];//ѡ��
        }
    }
    #endregion

    #region ��ť����
    /*****************��ť����******************/
    void Select_Answer(int index)
    {
        switch (index)
        {
            case 0://��ʾ
                int idx = ArrayX[topicIndex].Length - 1;
                int n = int.Parse(ArrayX[topicIndex][idx]);
                string nM = "";
                switch (n)
                {
                    case 1:
                        nM = "A";
                        break;
                    case 2:
                        nM = "B";
                        break;
                    case 3:
                        nM = "C";
                        break;
                    case 4:
                        nM = "D";
                        break;
                }
                tipsText.text = "<color=#FFAB08FF>" + "��ȷ���ǣ�" + nM + "</color>";
                break;
            case 1://��һ��
                if (topicIndex > 0)
                {
                    topicIndex--;
                    LoadAnswer();
                }
                else
                {
                    tipsText.text = "<color=#27FF02FF>" + "ǰ���Ѿ�û����Ŀ�ˣ�" + "</color>";
                }
                break;
            case 2://��һ��
                if (topicIndex < topicMax - 1)
                {
                    topicIndex++;
                    LoadAnswer();
                }
                else
                {
                    tipsText.text = "<color=#27FF02FF>" + "��ѽ���Ѿ������һ���ˡ�" + "</color>";
                }
                break;
            case 3://��ת
                int x = int.Parse(jumpInput.text) - 1;
                if (x >= 0 && x < topicMax)
                {
                    topicIndex = x;
                    jumpInput.text = "";
                    LoadAnswer();
                }
                else
                {
                    tipsText.text = "<color=#27FF02FF>" + "���ڷ�Χ�ڣ�" + "</color>";
                }
                break;
        }
    }
    #endregion

    #region ��Ŀ�Դ��ж�
    /*****************��Ŀ�Դ��ж�******************/
    void AnswerRightRrongJudgment(bool check, int index)
    {
        if (check)
        {
            //�ж���Ŀ�Դ�
            bool isRight;
            int idx = ArrayX[topicIndex].Length - 1;
            int n = int.Parse(ArrayX[topicIndex][idx]) - 1;
            if (n == index)
            {
                tipsText.text = "<color=#27FF02FF>" + "��ϲ�㣬����ˣ�" + "</color>";
                isRight = true;
                num.rightQuestions += 1;
                num.controlmusic += 1;
                tipsbtn.SetActive(true);
            }
            else
            {
                tipsText.text = "<color=#FF0020FF>" + "�Բ��𣬴���ˣ�" + "</color>";
                isRight = false;
                num.rightQuestions += 1;
                tipsbtn.SetActive(true);
            }

            //��ȷ�ʼ���
            if (isAnserList[topicIndex])
            {
                tipsText.text = "<color=#FF0020FF>" + "������Ѵ����" + "</color>";
            }
            else
            {
                anserint++;
                if (isRight)
                {
                    isRightNum++;
                }
                isAnserList[topicIndex] = true;
                TextAccuracy.text = "��ȷ�ʣ�" + ((float)isRightNum / anserint * 100).ToString("f2") + "%";
            }

            //���õ�ѡ��
            for (int i = 0; i < toggleList.Count; i++)
            {
                toggleList[i].interactable = false;
            }
        }
    }
    #endregion

    public void changePicture()
    {
        if (topicIndex == 0)
            faceImage.sprite = face00;
        if (topicIndex == 1)
            faceImage.sprite = face01;
        if (topicIndex == 2)
            faceImage.sprite = face02;
        if (topicIndex == 3)
            faceImage.sprite = face03;
        if (topicIndex == 4)
            faceImage.sprite = face04;
        if (topicIndex == 5)
            faceImage.sprite = face05;
        if (topicIndex == 6)
            faceImage.sprite = face06;
        if (topicIndex == 7)
            faceImage.sprite = face07;
        if (topicIndex == 8)
            faceImage.sprite = face08;
        if (topicIndex == 9)
            faceImage.sprite = face09;
        if (topicIndex == 10)
            faceImage.sprite = face10;
        if (topicIndex == 11)
            faceImage.sprite = face11;
        if (topicIndex == 12)
            faceImage.sprite = face12;
        if (topicIndex == 13)
            faceImage.sprite = face13;
        if (topicIndex >= 14)
            faceImage.sprite = face14;
    }
}
