using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EnterRoom : MonoBehaviour
{
    private bool isEnd;
    private bool button;
    public GameObject Button;   // ��ʾ��ť
    public int fen; // ��ת�������
    public string LevelName;   // ��ת�ؿ�������

    public NumCheck num;

    void Start()
    {
        num = GameObject.FindGameObjectWithTag("NumCheck").GetComponent<NumCheck>();
    }

    void Update()
    {
        button = Input.GetButtonDown("EnterDoor");  // ������EneterDoor��Ӧ��i
        if (button && isEnd && num.task == fen)
        {
            PressSelection(LevelName);
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player") && collision.GetType().ToString() == "UnityEngine.CapsuleCollider2D")
        {
            Button.SetActive(true);
            //Debug.Log("Player�����ŵķ�Χ");
            isEnd = true;
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player") && collision.GetType().ToString() == "UnityEngine.CapsuleCollider2D")
        {
            Button.SetActive(false);
            //Debug.Log("Player�뿪�ŵķ�Χ");
            isEnd = false;
        }
    }
    public void PressSelection(string _LevelName)     // �����ť����Ӧ�Ĺؿ�
    {
        SceneManager.LoadScene(_LevelName);
    }
}
