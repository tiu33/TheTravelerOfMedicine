using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Card : MonoBehaviour
{
    public CardState cardState;
    public CardPattern CardPattern;
    public GameManager gameManager;
    public int State = 0;
    // Start is called before the first frame update
    void Start()
    {
        cardState = CardState.δ����;
        gameManager = GameObject.FindGameObjectWithTag("GameManager").GetComponent<GameManager>();
    }

    private void OnMouseDown()
    {
        if(cardState.Equals(CardState.�ѷ���))
        {
            return;
        }
        if(gameManager.ReadyToCompareCards)
        {
            return;
        }
        OpenCard();
        gameManager.AddCardInCardComparison(this);
        gameManager.CompareCardInList();
    }
    void OpenCard()
    {
        transform.eulerAngles = new Vector3(0, 180, 0); // y��ת180�ȣ�����
        cardState = CardState.�ѷ���;
    }
}
 
public enum CardState
{
    δ����,�ѷ���,��Գɹ�
}
public enum CardPattern
{
    ��,�ջ�,������,����,����
}
