using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arrow : MonoBehaviour
{
    public float speed;
    public int damage;
    public float destroyDistance;

    private Rigidbody2D rb;
    private Vector3 startPos;

    void Start()
    {
        rb= GetComponent<Rigidbody2D>();
        if(GameObject.FindGameObjectWithTag("Player").transform.localScale.x == 1)
        {
            rb.velocity = transform.right * speed;
        }
        if (GameObject.FindGameObjectWithTag("Player").transform.localScale.x == -1)
        {
            rb.velocity = transform.right * -speed;
            transform.localScale = new Vector3(1, 1, 1);
        }
        
        startPos = transform.position;
    }

    void Update()
    {
        float distance = (transform.position - startPos).sqrMagnitude;
        if (Mathf.Abs(distance) > destroyDistance)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
            collision.GetComponent<Enemy>().TakeDamage(damage);
        }
    }
}
