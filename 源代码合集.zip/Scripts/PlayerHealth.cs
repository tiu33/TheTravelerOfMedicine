using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHealth : MonoBehaviour
{
    AudioSource audioSource;

    public int health;
    public int Blinks;
    public float time;
    private Renderer myRender;
    private float invisibleTime;

    public AudioClip hurt;
    public GameObject bloodEffect;
    public GameObject healEffect;
    private PlayerDeath Pd;

    void Start()
    {
        HealthBar.healthMax = health;
        HealthBar.healthCurrent = health;
        myRender = GetComponent<Renderer>();
        Pd = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerDeath>();
        audioSource = GetComponent<AudioSource>();
    }


    public void DamagePlayer(int damage)
    {
        if (invisibleTime > 0)
        {
            return;
        }
        Instantiate(bloodEffect, transform.position, Quaternion.identity);
        invisibleTime = 1;
        Invoke("SetBack", invisibleTime);   // �޵�֡
        health -= damage;
        if(health < 0)
        {
            health = 0;
        }
        HealthBar.healthCurrent = health;
        audioSource.clip = hurt;
        audioSource.Play();
        if (health <= 0)
        {
            Pd.Death(); // �е�playerDeath������������
        }
        StartCoroutine(DoBlinks(Blinks, time)); ;  // ��һ����˸�������ڶ�����˸ʱ��
    }

    public void healPlayer(int heal)
    {
        Instantiate(healEffect, transform.position, Quaternion.identity);
        health += heal;
        HealthBar.healthCurrent = health;
        audioSource.clip = hurt;
        audioSource.Play();
        StartCoroutine(DoBlinks(Blinks, time)); ;  // ��һ����˸�������ڶ�����˸ʱ��
    }

    IEnumerator DoBlinks(int numBlinks, float second)
    {
        for (int i = 0; i < numBlinks; i++)
        {
            myRender.enabled = !myRender.enabled;
            yield return new WaitForSeconds(second);
        }
        myRender.enabled = true;
    }

    public void healthSet(int blood)    // made��ֱ�ӵ��ڲ��У���Ҫ����һ�飬������Ϊʲô��̫������
    {
        // ̫�����ˣ��������˸�Ѫ���仯
        health = blood;
        HealthBar.healthCurrent = health;     
    }
    void SetBack()
    {
        invisibleTime = 0;
    }
}
