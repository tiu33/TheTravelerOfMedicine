using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Healing : MonoBehaviour
{
    private bool button;
    public bool isHeal;
    public GameObject Button;
    private Fruits playerBanana;

    private void Start()
    {
        playerBanana = GameObject.FindGameObjectWithTag("Player").GetComponent<Fruits>();
    }
    void Update()
    {
        button = Input.GetButtonDown("EnterDoor");
        if (button)
        {
            HealBody();
        }
    }
    void HealBody()    // ���ƹ���
    {
        if (isHeal)
        {
            playerBanana.bananaHeal();
        }
    }

    #region ��ײ���
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player") && collision.GetType().ToString() == "UnityEngine.CapsuleCollider2D")
        {
            Button.SetActive(true);
            //Debug.Log("Player�����ŵķ�Χ");
            isHeal = true;
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player") && collision.GetType().ToString() == "UnityEngine.CapsuleCollider2D")
        {
            Button.SetActive(false);
            //Debug.Log("Player�뿪�ŵķ�Χ");
            isHeal = false;
        }
    }
    #endregion
}
