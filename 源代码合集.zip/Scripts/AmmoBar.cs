using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AmmoBar : MonoBehaviour
{
    public static float currentTime;
    public static float coolTime;
    private Image ammoBar;

    void Start()
    {
        ammoBar = GetComponent<Image>();
    }


    void Update()
    {
        ammoBar.fillAmount = currentTime / (coolTime+0.01f);    // С���ܼ�ʱ��
    }
}
