using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestData : MonoBehaviour
{
    public int test,a,b;
    public int playerHP;
    public int banana;
    public Transform playerTransform;
    private Fruits fruits;
    private PlayerHealth playerHealth;
    

    void Start()
    {
        playerTransform = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        playerHealth = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerHealth>();
        fruits = GameObject.FindGameObjectWithTag("Player").GetComponent<Fruits>();
    }

    void Update()
    {
        
    }
    public void Save()
    {
        SaveSystem.SetVector3("TEST",transform.position);
        playerHP = playerHealth.health;
        SaveSystem.SetInt("TEST1", playerHP);
        banana = fruits.bananas;
        SaveSystem.SetInt("TEST2", banana);
        Debug.Log(banana);
        Debug.Log("�Ѵ洢����");
    }
    public void Load()
    {
        playerTransform.position = SaveSystem.GetVector3("TEST");
        playerHP = SaveSystem.GetInt("TEST1");
        banana = SaveSystem.GetInt("TEST2");
        Debug.Log(banana);
        playerHealth.healthSet(playerHP);
        fruits.bananaSet(banana);
    }
}
