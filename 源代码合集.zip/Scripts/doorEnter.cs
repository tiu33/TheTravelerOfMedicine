using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class doorEnter : MonoBehaviour
{
    public Transform backDoor;
    private bool button;
    private bool isDoor;
    private Transform playerTransform;
    public GameObject Button;
    void Start()
    {
        playerTransform = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
    }

    void Update()
    {
        button = Input.GetButtonDown("EnterDoor");
        if (button)
        {
            EnterDoor();
        }
    }
    void EnterDoor()    // ���͹���
    {
        if (isDoor)
        {
            playerTransform.position = backDoor.position;
        }
    }

    #region ��ײ���
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player")&&collision.GetType().ToString()=="UnityEngine.CapsuleCollider2D")
        {
            Button.SetActive(true);
            //Debug.Log("Player�����ŵķ�Χ");
            isDoor = true;
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player") && collision.GetType().ToString() == "UnityEngine.CapsuleCollider2D")
        {
            Button.SetActive(false);
            //Debug.Log("Player�뿪�ŵķ�Χ");
            isDoor = false;
        }
    }
    #endregion
}
