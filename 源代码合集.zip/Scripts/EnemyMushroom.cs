using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMushroom : Enemy
{
    public float speed;
    public float startWaitTime;
    private float waitTime;

    public Transform movePos;
    public Transform leftDownPos;
    public Transform rightUpPos;
    void Start()
    {
        base.Start();
        waitTime = startWaitTime;
        movePos.position = GetRandomPos();
    }

    void Update()
    {
        base.Update();
        TransScale();
        transform.position = Vector2.MoveTowards(transform.position,movePos.position,speed*Time.deltaTime); // �ƶ�
        if (Vector2.Distance(transform.position, movePos.position) < 0.1f)  // �ж϶���λ��
        {
            if (waitTime <= 0)  // �ȴ�ʱ�����
            {
                movePos.position = GetRandomPos();
            }
            else
            {
                waitTime -= Time.deltaTime; // ͣ��һ��ʱ��
            }
        }
    }
    Vector2 GetRandomPos()  // ��������ƶ�λ��
    {
        return new Vector2(Random.Range(leftDownPos.position.x,rightUpPos.position.x),Random.Range(leftDownPos.position.y, rightUpPos.position.y));     
    } 
    public void TransScale()    // ����ת��
    {
        if (transform.position.x < movePos.position.x)
        {
            transform.rotation = Quaternion.Euler(0f, 180f, 0f);
        }
        else
        {
            transform.rotation = Quaternion.Euler(0f, 0f, 0f);
        }
    }
}
