using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySmartMushroom : Enemy
{
    Rigidbody2D rb;
    public float speed;
    public float radius;    // �����ҷ�Χ
    protected bool facingRight = true;

    [SerializeField]
    protected Transform playerTransform;
    void Start()
    {
        base.Start();
        playerTransform = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        rb = GetComponent<Rigidbody2D>();

    }

    public void Update()
    {
        base.Update();
        #region �����ƶ�
        if (playerTransform != null)
        {
            //float distance = (transform.position - playerTransform.position).sqrMagnitude;  // ���������ľ���
            float distance = (transform.position.x - playerTransform.position.x);
            float trueDistance = (transform.position - playerTransform.position).sqrMagnitude;
            if (trueDistance < radius)
            {
                transform.position = Vector2.MoveTowards(transform.position,
                    playerTransform.position,
                    speed * Time.deltaTime);
            }
            if (distance > 0 && facingRight == false)
            {
                //Vector2 enemyVel = new Vector2(-1.0f * speed, rb.velocity.y);
                //rb.velocity = enemyVel;
                //transform.position = Vector2.MoveTowards(transform.position,
                //    playerTransform.position,
                //    speed * Time.deltaTime);    // �˺�������һ����������һ�����ƶ�
                Flip();
            }
            else if (distance < 0 && facingRight == true)
            {
                //Vector2 enemyVel = new Vector2(1.0f * speed, rb.velocity.y);
                //rb.velocity = enemyVel;
                Flip();
            }
        }
        #endregion
    }
    private void Flip() // ��ת
    {
        facingRight = !facingRight;
        Vector3 playerScale = transform.localScale;
        playerScale.x *= -1;
        transform.localScale = playerScale;
    }
}
